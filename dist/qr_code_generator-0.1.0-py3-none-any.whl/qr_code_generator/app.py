# - - - program flow - - -
# input link
# generate qr code


import qrcode

def input_URL():
	url = str(input("enter the url you need to make a qr code for (use www.name.com) : "))
	http_prefix = "https://"
	full_url = f"{http_prefix}{url}"
	return full_url

qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=15, border=4)
url = input_URL()
qr.add_data(url)
qr.make(fit=True)

img = qr.make_image(fill_color="red", back_color="white")
img.save("url_qrcode.png")

print(qr.data_list)