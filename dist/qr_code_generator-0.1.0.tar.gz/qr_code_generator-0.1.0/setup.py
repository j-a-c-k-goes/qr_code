# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['qr_code_generator']

package_data = \
{'': ['*']}

install_requires = \
['qrcode>=7.3.1,<8.0.0']

setup_kwargs = {
    'name': 'qr-code-generator',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'jack',
    'author_email': 'jack@flnpb.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
